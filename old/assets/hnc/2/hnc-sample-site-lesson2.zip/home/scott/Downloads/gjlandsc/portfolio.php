<?php date_default_timezone_set('Europe/London'); ?>
<!DOCTYPE html>

<html>
<head>
    <title>GJ Landscape Maintenance | Portfolio</title>
    
    <meta name="description" content="This page provides a portfolio of our previous work, including grass cutting, tree maintenance, grounds maintenance and waste clearance. | GJ Landscape Maintenance">
    <link rel="author" href="https://plus.google.com/101278770842385774855"/>
    
    <link rel="stylesheet" type="text/css" href="styles/main.css">

    <script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-49751789-3', 'auto');
	  ga('require', 'displayfeatures');
	  ga('send', 'pageview');

	</script>
</head>

<body>
    <div id="wrapper">
        <div id="logo">
            <img src="images/logo.jpg", alt="GJ Landscapes Logo"/>
        </div>
        <header id="top">
            <h1>GJ Landscape Maintenance</h1>
            <div class="navbar">
                <nav id="mainnav">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">Portfolio</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </header>
        <div id="portfolio">
        	<h3>Grass Cutting:</h3>
            <div class="img">
              <a target="_blank" href="images/portfolio_1.jpg">
              <img src="images/portfolio_1_small.jpg" alt="GJ Landscapes Portfolio Image 1" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_2.jpg">
              <img src="images/portfolio_2_small.jpg" alt="GJ Landscapes Portfolio Image 2" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_3.jpg">
              <img src="images/portfolio_3_small.jpg" alt="GJ Landscapes Portfolio Image 3" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_4.jpg">
              <img src="images/portfolio_4_small.jpg" alt="GJ Landscapes Portfolio Image 4" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_15.jpg">
              <img src="images/portfolio_15_small.jpg" alt="GJ Landscapes Portfolio Image 15" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_16.jpg">
              <img src="images/portfolio_16_small.jpg" alt="GJ Landscapes Portfolio Image 16" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_7.jpg">
              <img src="images/portfolio_7_small.jpg" alt="GJ Landscapes Portfolio Image 7" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_19.jpg">
              <img src="images/portfolio_19_small.jpg" alt="GJ Landscapes Portfolio Image 19" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            
            <h3>Tree Maintenance:</h3>
            <div class="img">
              <a target="_blank" href="images/portfolio_5.jpg">
              <img src="images/portfolio_5_small.jpg" alt="GJ Landscapes Portfolio Image 5" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_6.jpg">
              <img src="images/portfolio_6_small.jpg" alt="GJ Landscapes Portfolio Image 6" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_8.jpg">
              <img src="images/portfolio_8_small.jpg" alt="GJ Landscapes Portfolio Image 8" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_12.jpg">
              <img src="images/portfolio_12_small.jpg" alt="GJ Landscapes Portfolio Image 12" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_17.jpg">
              <img src="images/portfolio_17_small.jpg" alt="GJ Landscapes Portfolio Image 17" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>

            <h3>Grounds Maintenance & Waste Clearance:</h3>
            <div class="img">
              <a target="_blank" href="images/portfolio_9.jpg">
              <img src="images/portfolio_9_small.jpg" alt="GJ Landscapes Portfolio Image 9" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_13.jpg">
              <img src="images/portfolio_13_small.jpg" alt="GJ Landscapes Portfolio Image 13" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_14.jpg">
              <img src="images/portfolio_14_small.jpg" alt="GJ Landscapes Portfolio Image 14" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_10.jpg">
              <img src="images/portfolio_10_small.jpg" alt="GJ Landscapes Portfolio Image 10" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
            <div class="img">
              <a target="_blank" href="images/portfolio_11.jpg">
              <img src="images/portfolio_11_small.jpg" alt="GJ Landscapes Portfolio Image 11" width="330" height="190">
              </a>
              <!-- <div class="desc">Description</div> -->
            </div>
        </div>
    </div>
	<footer>
		<div id="copyright">
		<?php
			date_default_timezone_set('Europe/London');
			$year = date("Y");    
			print('&copy; Copyright GJ Landscape Maintenance '.$year);
		?>
		</div>
		<div id="webmaster">
			Website by <a href="http://uk.linkedin.com/pub/scott-morgan/72/871/57b/" target="_blank">Scott Morgan</a>
		</div>
	</footer>
</body>
</html>
