<?php date_default_timezone_set('Europe/London'); ?>
<!DOCTYPE html>

<html>
<head>
    <title>GJ Landscape Maintenance | Contact Us</title>
    
    <meta name="description" content="Contact Gareth Howell of GJ Landscape Maintenance using the contact details on this page. | GJ Landscape Maintenance">
    <link rel="author" href="https://plus.google.com/101278770842385774855"/>
    
    <link rel="stylesheet" type="text/css" href="styles/main.css">
    <link rel="stylesheet" href="styles/ajax_contact.css">
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="scripts/app.js"></script>
    
    <script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-49751789-3', 'auto');
	  ga('require', 'displayfeatures');
	  ga('send', 'pageview');

	</script>
</head>

<body>
    <div id="wrapper">
        <div id="logo">
            <img src="images/logo.jpg", alt="GJ Landscape Maintenance Logo"/>
        </div>
        <header id="top">
            <h1>GJ Landscape Maintenance</h1>
            <div class="navbar">
                <nav id="mainnav">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="portfolio.php">Portfolio</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </header>
        <article id="contact">
            <p>To find out more about our products and services, please contact Gareth Howell:</p>
            <p>GJ Landscape Maintenance<br>
                72 Coychurch Road<br>
                Pencoed<br>
                Bridgend<br>
                CF35 5NA</p>
                <p>Tel: 01656 860272<br>
                Mobile: 07816 566283<br>
                E-mail: <a href="mailto:ghowell@gjlandscapemaintenance.co.uk">ghowell@gjlandscapemaintenance.co.uk</a></p>
                
			<p><br></p>
			<p>Or you can get in touch quickly by filling out the form below:</p>
        </article>
    </div>
    <div id="contactForm">
			<div id="form-messages"></div>
			<form id="ajax-contact" method="post" action="includes/mailer.php">
				<div class="field">
					<label for="name">Name:</label>
					<input type="text" id="name" name="name" required>
				</div>

				<div class="field">
					<label for="email">Email:</label>
					<input type="email" id="email" name="email" required>
				</div>

				<div class="field">
					<label for="message">Message:</label>
					<textarea id="message" name="message" required></textarea>
				</div>

				<div class="field">
					<button type="submit">Send</button>
				</div>
			</form>
		</div>
	<footer>
		<div id="copyright">
		<?php
			
			$year = date("Y");    
			print('&copy; Copyright GJ Landscape Maintenance '.$year);
		?>
		</div>
		<div id="webmaster">
			Website by <a href="http://uk.linkedin.com/pub/scott-morgan/72/871/57b/" target="_blank">Scott Morgan</a>
		</div>
	</footer>
</body>
</html>
