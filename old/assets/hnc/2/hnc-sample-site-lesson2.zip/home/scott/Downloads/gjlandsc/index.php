<?php date_default_timezone_set('Europe/London'); ?>
<!DOCTYPE html>

<html>
<head>
    <title>GJ Landscape Maintenance | Home</title>
    
    <meta name="description" content="GJ Landscape Maintenance provides a professional service for all ground and garden maintenance projects. Based mainly in Pencoed, Bridgend and Cardiff and the surrounding areas, we cater for all types of customer from commercial to domestic and will provide a professional, affordable service to all. | GJ Landscape Maintenance">
    <link rel="author" href="https://plus.google.com/101278770842385774855"/>
    <meta name="google-site-verification" content="5T9I-rNsdr9X8bkvrrDZ4AHpIiiP_lDZkh9kHIegUB4" />
    
    <link rel="stylesheet" type="text/css" href="styles/main.css">

    
    <script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-49751789-3', 'auto');
	  ga('require', 'displayfeatures');
	  ga('send', 'pageview');

	</script>
</head>

<body>
    <div id="wrapper">
        <div id="logo">
            <img src="images/logo.jpg", alt="GJ Landscapes Logo"/>
        </div>
        <header id="top">
            <h1>GJ Landscape Maintenance</h1>
            <div class="navbar">
                <nav id="mainnav">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="portfolio.php">Portfolio</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </header>
        <div id="hero">
            <article><img src="images/hero.jpg" alt="GJ Landscapes & Maintenance Main"/></article>
            <article class="rightfloat">
                <h3>Contact Us</h3>
                <p>GJ Landscape Maintenance<br>
                72 Coychurch Road<br>
                Pencoed<br>
                Bridgend<br>
                CF35 5NA</p>
                <p>Tel: 01656 860272<br>
                Mobile: 07816 566283<br><br>
                E-mail: <small><a href="mailto:ghowell@gjlandscapemaintenance.co.uk">ghowell@gjlandscapemaintenance.co.uk</a></small></p>
            </article>
        </div>
        <article class="home_maintext">
            <h3>About Us:</h3>
            <p>At GJ Landscape Maintenance, we provide a professional service for all your grounds maintenance projects. With over <?php $date = idate('Y'); $diff = $date - 1988; echo "$diff"; ?> years experience, we cater for all types of customer from commercial to domestic and will provide a professional, affordable service to all. Some of the services we offer are outlined below:
            <ul>
	            <li>Grass cutting</li>
	            <li>Weed spraying</li>
	            <li>Hedge cutting</li>
	            <li>Tree maintenance and felling</li>
	            <li>Litter picking</li>
	        </ul>
	        If you would like to find out more about our services, please don't hesitate to <a href="contact.php">contact us</a>.
            </p>
        </article>
        <article class="home_maintext">
            <h3>Areas We Cover:</h3>
            <p>Based in Pencoed, Bridgend, our services cover the following areas: 
             <ul>
	            <li>Bridgend</li>
	            <li>Vale of Glamorgan</li>
	            <li>Cardiff and surrounding areas</li>
	        </ul>
	        This is by no means an exhaustive list. If you would like to find out more about the areas we cover, please don't hesitate to <a href="contact.php">contact us</a>.
	        </p>
        </article>
        <article class="home_maintext">
            <h3>Qualifications and Certificates:</h3>
            <p>
            <ul>
            <li>NPTC qualified in the safe use of pesticides.</li>
            <li>NPTC qualified for chainsaw use.</li>
            <li>All staff are fully insured and trained to the highest standard.</li>
            <li>Licensed waste carriers.</li>
            </ul></p>
        </article>
    </div>
    <footer>
        <div id="copyright">
        <?php
            date_default_timezone_set('Europe/London');
            $year = date("Y");    
            print('&copy; Copyright GJ Landscape Maintenance '.$year);
        ?>
        </div>
        <div id="webmaster">
            Website by <a href="http://uk.linkedin.com/pub/scott-morgan/72/871/57b/" target="_blank">Scott Morgan</a>
        </div>
    </footer>
</body>
</html>
