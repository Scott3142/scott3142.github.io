<?php date_default_timezone_set('Europe/London'); ?>
<!DOCTYPE html>

<html>
<head>
    <title>GJ Landscape Maintenance | 403 Forbidden</title>
    
    <meta name="description" content="GJ Landscape Maintenance provides a professional service for all grounds maintenance projects. Based mainly in Pencoed, Bridgend, Cardiff and the surrounding areas, we cater for all types of customer from commercial to domestic and will provide a professional, affordable service to all. | GJ Landscape Maintenance">
    <link rel="author" href="https://plus.google.com/101278770842385774855"/>
    
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" type="text/css" href="styles/main.css">
        
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-49751789-1', 'gjlandscapemaintenance.co.uk');
	  ga('require', 'displayfeatures');
	  ga('send', 'pageview');

    </script>
</head>

<body>
    <div id="wrapper">
        <div id="logo">
            <img src="images/logo.jpg", alt="GJ Landscapes Logo"/>
        </div>
        <header id="top">
            <h1>GJ Landscape Maintenance</h1>
            <div class="navbar">
                <nav id="mainnav">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="portfolio.php">Portfolio</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </nav>
            </div>
        </header>
		<article class="error_mainbody">
            <p><strong>Oops! 403 Forbidden</strong></p>
            <p>You do not have permission to access this file on the server.</p>
            <p>You're best off navigating back to the <a href="../index.php">home page</a> now and hoping for the best.</p>
            
            <p><br>Please contact the <a href="mailto:webmaster@gjlandscapemaintenance.co.uk">webmaster</a> to report site failures.</p>
        </article>
    </div>
    <footer>
        <div id="copyright">
        <?php
            date_default_timezone_set('Europe/London');
            $year = date("Y");    
            print('&copy; Copyright GJ Landscape Maintenance '.$year);
        ?>
        </div>
        <div id="webmaster">
            Website by <a href="http://uk.linkedin.com/pub/scott-morgan/72/871/57b/" target="_blank">Scott Morgan</a>
        </div>
    </footer>
</body>
</html>
